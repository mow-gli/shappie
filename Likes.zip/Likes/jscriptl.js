function likes(){
    var number= document.getElementById("likes");
    number.innerText= document.getElementById("likes").innerText;
    console.log(number.innerText++);
}

