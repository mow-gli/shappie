console.log("page loaded...");

function message() {
    alert("Ninja was liked!");
}

function login(element) {
    element.innerText = "logout";
}

function hide(el) {
    el.remove();
}